

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/admin">Dashboard</a></li>
                        <li class="breadcrumb-item active">Payment Gateways</li>
                    </ol>
                </div>
                <h4 class="page-title">Payment Gateway Management</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title mb-0">Available Payment Gateways</h5>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <?php $__currentLoopData = $paymentGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 border <?php echo e($gateway['is_active'] ? 'border-success' : 'border-secondary'); ?>">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center mb-3">
                                            <?php if($gateway['logo']): ?>
                                                <img src="<?php echo e($gateway['logo']); ?>" alt="<?php echo e($gateway['name']); ?>" class="me-3" style="height: 40px;">
                                            <?php else: ?>
                                                <div class="bg-primary text-white rounded-circle me-3 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                    <i class="fas fa-credit-card"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <h6 class="mb-0"><?php echo e($gateway['name']); ?></h6>
                                                <small class="text-muted"><?php echo e($gateway['slug']); ?></small>
                                            </div>
                                        </div>
                                        
                                        <p class="text-muted small mb-3"><?php echo e($gateway['description']); ?></p>
                                        
                                        <div class="mb-3">
                                            <strong>Supported Currencies:</strong>
                                            <div class="mt-1">
                                                <?php $__currentLoopData = $gateway['supported_currencies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge bg-light text-dark me-1"><?php echo e($currency); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <strong>Fees:</strong>
                                            <span class="text-muted"><?php echo e($gateway['fees']); ?></span>
                                        </div>
                                        
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <?php if($gateway['is_active']): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Inactive</span>
                                                <?php endif; ?>
                                                
                                                <?php if($gateway['is_test_mode']): ?>
                                                    <span class="badge bg-warning ms-1">Test Mode</span>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('admin.payments.configure', $gateway['slug'])); ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-cog"></i> Configure
                                                </a>
                                                <form action="<?php echo e(route('admin.payments.toggle', $gateway['slug'])); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-sm <?php echo e($gateway['is_active'] ? 'btn-outline-warning' : 'btn-outline-success'); ?>">
                                                        <i class="fas fa-power-off"></i>
                                                        <?php echo e($gateway['is_active'] ? 'Disable' : 'Enable'); ?>

                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xpertbid\xpertbid-new\xpertbid-new\backend\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>