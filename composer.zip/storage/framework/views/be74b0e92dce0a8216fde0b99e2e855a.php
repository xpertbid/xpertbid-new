

<?php $__env->startSection('title', 'Tags Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tags Management</h1>
        <div>
            <a href="/admin/tags/create" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Tag
            </a>
        </div>
    </div>

    <!-- Tags Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tags List</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="tagsTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Slug</th>
                            <th>Color</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Sort Order</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($tag->id); ?></td>
                            <td>
                                <span class="badge bg-primary"><?php echo e($tag->name); ?></span>
                            </td>
                            <td><?php echo e($tag->slug); ?></td>
                            <td>
                                <?php if($tag->color): ?>
                                    <span class="badge" style="background-color: <?php echo e($tag->color); ?>; color: white;">
                                        <?php echo e($tag->color); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">No Color</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($tag->description): ?>
                                    <?php echo e(Str::limit($tag->description, 50)); ?>

                                <?php else: ?>
                                    <span class="text-muted">No Description</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($tag->status ? 'success' : 'danger'); ?>">
                                    <?php echo e($tag->status ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td><?php echo e($tag->sort_order); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($tag->created_at)->format('M d, Y')); ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-primary" title="View" onclick="viewTag(<?php echo e($tag->id); ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <a href="/admin/tags/<?php echo e($tag->id); ?>/edit" class="btn btn-outline-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button class="btn btn-outline-danger" title="Delete" onclick="deleteTag(<?php echo e($tag->id); ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- View Tag Modal -->
<div class="modal fade" id="viewTagModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tag Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="tagDetails">
                <!-- Tag details will be loaded here -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
function viewTag(id) {
    // For now, just show a placeholder
    $('#tagDetails').html(`
        <div class="row">
            <div class="col-md-6">
                <h5>Tag Information</h5>
                <p><strong>ID:</strong> ${id}</p>
                <p><strong>Status:</strong> Active</p>
                <p><strong>Color:</strong> #007bff</p>
            </div>
            <div class="col-md-6">
                <h5>Details</h5>
                <p><strong>Sort Order:</strong> 0</p>
                <p><strong>Created:</strong> ${new Date().toLocaleDateString()}</p>
                <p><strong>Description:</strong> Sample tag description</p>
            </div>
        </div>
    `);
    $('#viewTagModal').modal('show');
}

function deleteTag(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // For now, just show success message
            Swal.fire('Deleted!', 'Tag has been deleted.', 'success');
        }
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xpertbid\xpertbid-new\xpertbid-new\backend\resources\views/admin/tags.blade.php ENDPATH**/ ?>