

<?php $__env->startSection('title', 'Languages Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Languages Management</h1>
        <div>
            <a href="/admin/languages/create" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Language
            </a>
        </div>
    </div>

    <!-- Languages Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Languages List</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="languagesTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Flag</th>
                            <th>Name</th>
                            <th>Code</th>
                            <th>Native Name</th>
                            <th>RTL</th>
                            <th>Status</th>
                            <th>Default</th>
                            <th>Sort Order</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($language->id); ?></td>
                            <td>
                                <?php if($language->flag_url): ?>
                                    <img src="<?php echo e($language->flag_url); ?>" width="32" height="24" class="rounded">
                                <?php else: ?>
                                    <img src="/images/no-flag.png" width="32" height="24" class="rounded">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($language->name); ?></td>
                            <td>
                                <span class="badge bg-info"><?php echo e(strtoupper($language->code)); ?></span>
                            </td>
                            <td><?php echo e($language->native_name); ?></td>
                            <td>
                                <?php if($language->direction === 'rtl'): ?>
                                    <span class="badge bg-warning">RTL</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">LTR</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($language->is_active ? 'success' : 'danger'); ?>">
                                    <?php echo e($language->is_active ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($language->is_default): ?>
                                    <span class="badge bg-primary">
                                        <i class="fas fa-star"></i> Default
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Regular</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($language->sort_order); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($language->created_at)->format('M d, Y')); ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-primary" title="View" onclick="viewLanguage(<?php echo e($language->id); ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <a href="/admin/languages/<?php echo e($language->id); ?>/edit" class="btn btn-outline-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php if(!$language->is_default): ?>
                                        <button class="btn btn-outline-success" title="Set Default" onclick="setDefaultLanguage(<?php echo e($language->id); ?>)">
                                            <i class="fas fa-star"></i>
                                        </button>
                                    <?php endif; ?>
                                    <button class="btn btn-outline-danger" title="Delete" onclick="deleteLanguage(<?php echo e($language->id); ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- View Language Modal -->
<div class="modal fade" id="viewLanguageModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Language Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="languageDetails">
                <!-- Language details will be loaded here -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
function viewLanguage(id) {
    // For now, just show a placeholder
    $('#languageDetails').html(`
        <div class="row">
            <div class="col-md-6">
                <h5>Language Information</h5>
                <p><strong>ID:</strong> ${id}</p>
                <p><strong>Status:</strong> Active</p>
                <p><strong>Default:</strong> No</p>
            </div>
            <div class="col-md-6">
                <h5>Details</h5>
                <p><strong>Code:</strong> EN</p>
                <p><strong>RTL:</strong> No</p>
                <p><strong>Sort Order:</strong> 1</p>
            </div>
        </div>
    `);
    $('#viewLanguageModal').modal('show');
}

function setDefaultLanguage(id) {
    Swal.fire({
        title: 'Set as Default?',
        text: "This will make this language the default for the system.",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, set as default!'
    }).then((result) => {
        if (result.isConfirmed) {
            // For now, just show success message
            Swal.fire('Updated!', 'Default language has been updated.', 'success');
        }
    });
}

function deleteLanguage(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // For now, just show success message
            Swal.fire('Deleted!', 'Language has been deleted.', 'success');
        }
    });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xpertbid\xpertbid-new\xpertbid-new\backend\resources\views/admin/languages.blade.php ENDPATH**/ ?>